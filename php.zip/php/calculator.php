<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculator</title>
</head>
<body>
    <?php
    // $x = 10;
    // $y = 20;
    $a = readline('Enter Number 1 : ');
    echo $a;
    $b = readline('Enter Number 2 : ');
    echo $b;
    $c = $a + $b;
    echo "Addition is = $c";
    echo "<br>";
    $c = $a - $b;
    echo "Subtraction is = $c";
    echo "<br>";
    $c = $a * $b;
    echo "Multiplication is = $c";
    echo "<br>";
    // $c = $a / $b;
    // echo "Division is = $c";

    ?>
</body>
</html>